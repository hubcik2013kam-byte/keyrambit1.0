#!/usr/bin/env python3
"""Generuje tekstury karambitow (64x64, wygladzone), modele i definicje itemow.
Uruchom:  python3 tools/gen_assets.py [--preview]     (wymaga Pillow + numpy)
Nazwa: k<ksztalt>_<A>_<B>  -> gradient ostrza od koloru A (przy rekojesci) do B (czubek).
"""
import json, math, os, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

ROOT = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources", "assets", "karambitmod")
PAL = [(220, 40, 50), (255, 140, 30), (250, 220, 50), (60, 200, 80), (50, 220, 230),
       (50, 100, 240), (150, 70, 220), (255, 110, 190), (240, 240, 245), (35, 35, 45)]

S = 256          # rozdzielczosc robocza
OUT = 64         # rozdzielczosc tekstury

# ksztalt: (S0 podstawa grzbietu, C1 kontrola grzbietu, T czubek, E0 podstawa ostrza, C2 kontrola ostrza)
SHAPES = [
    dict(s0=(86, 152), c1=(72, 56), t=(238, 30), e0=(122, 180), c2=(176, 112)),   # klasyczny
    dict(s0=(92, 150), c1=(70, 36), t=(236, 52), e0=(116, 176), c2=(168, 92)),    # hawk: mocniej zakrzywiony
    dict(s0=(78, 156), c1=(76, 70), t=(240, 26), e0=(132, 186), c2=(186, 124)),   # gruby
]
HANDLE_TOP = (104, 166)
DIR = np.array([-0.7071, 0.7071])      # od ostrza w strone pierscienia
HANDLE_LEN = 62
HANDLE_W = 26
RING_R_OUT, RING_R_IN = 27, 15


def lerp(a, b, t):
    return tuple(a[i] + (b[i] - a[i]) * t for i in range(3))


def bez(p0, c, p1, n=220):
    t = np.linspace(0, 1, n)[:, None]
    p0, c, p1 = map(np.array, (p0, c, p1))
    return (1 - t) ** 2 * p0 + 2 * (1 - t) * t * c + t ** 2 * p1


def mask_poly(pts):
    im = Image.new("L", (S, S), 0)
    ImageDraw.Draw(im).polygon([tuple(p) for p in pts], fill=255)
    return np.array(im) > 127


def min_dist(grid_x, grid_y, curve):
    d = np.full(grid_x.shape, 1e9)
    for px, py in curve[::2]:
        d = np.minimum(d, np.hypot(grid_x - px, grid_y - py))
    return d


def build(shape, ca, cb):
    sh = SHAPES[shape]
    ys, xs = np.mgrid[0:S, 0:S].astype(np.float32)
    xs += 0.5; ys += 0.5

    spine = bez(sh["s0"], sh["c1"], sh["t"])
    edge = bez(sh["e0"], sh["c2"], sh["t"])
    blade = mask_poly(np.vstack([spine, edge[::-1]]))

    # --- rekojesc: kapsula od HANDLE_TOP w strone pierscienia
    h0 = np.array(HANDLE_TOP, dtype=float)
    h1 = h0 + DIR * HANDLE_LEN
    ax, ay = h1 - h0
    t = np.clip(((xs - h0[0]) * ax + (ys - h0[1]) * ay) / (ax * ax + ay * ay), 0, 1)
    dist_axis = np.hypot(xs - (h0[0] + t * ax), ys - (h0[1] + t * ay))
    handle = dist_axis <= HANDLE_W / 2
    # os poprzeczna (znak) do podswietlenia i rowkow
    nx, ny = -DIR[1], DIR[0]
    side = ((xs - h0[0]) * nx + (ys - h0[1]) * ny)
    along = ((xs - h0[0]) * DIR[0] + (ys - h0[1]) * DIR[1])

    # --- pierscien
    rc = h1 + DIR * 10
    rd = np.hypot(xs - rc[0], ys - rc[1])
    ring = (rd <= RING_R_OUT) & (rd >= RING_R_IN)

    # --- bolster (metalowa obejma na styku)
    bol = handle & (along < 9)

    alpha = blade | handle | ring
    rgb = np.zeros((S, S, 3), dtype=np.float32)

    # ---- ostrze
    da = min_dist(xs, ys, edge)
    ds = min_dist(xs, ys, spine)
    u = da / np.maximum(da + ds, 1e-3)             # 0 przy krawedzi tnacej, 1 przy grzbiecie
    # pozycja wzdluz ostrza -> gradient A->B
    bx0, by0 = (np.array(sh["s0"]) + np.array(sh["e0"])) / 2
    bx1, by1 = sh["t"]
    vx, vy = bx1 - bx0, by1 - by0
    g = np.clip(((xs - bx0) * vx + (ys - by0) * vy) / (vx * vx + vy * vy), 0, 1)
    A = np.array(PAL[ca], dtype=np.float32); B = np.array(PAL[cb], dtype=np.float32)
    base = A[None, None, :] * (1 - g[..., None]) + B[None, None, :] * g[..., None]
    shade = np.where(u < 0.30, 1.0 + 0.55 * (1 - u / 0.30),         # sciecie przy krawedzi: jasne
            np.where(u < 0.42, 0.95, 0.95 - 0.30 * (u - 0.42) / 0.58))  # reszta: ciemnieje ku grzbietowi
    blade_rgb = base * shade[..., None]
    # biala linia krawedzi + odblask
    edge_line = np.clip(1 - da / 5.0, 0, 1)[..., None]
    blade_rgb = blade_rgb * (1 - 0.7 * edge_line) + 255 * 0.7 * edge_line
    glint = np.exp(-((u - 0.55) / 0.045) ** 2) * np.clip(1 - g * 1.1, 0, 1) * 0.55
    blade_rgb = blade_rgb + 255 * glint[..., None] * (1 - blade_rgb / 400)
    rgb[blade] = np.clip(blade_rgb[blade], 0, 255)

    # ---- rekojesc (weglowe wlokno + paski koloru A)
    hh = np.zeros((S, S, 3), dtype=np.float32)
    hl = np.clip(0.5 - side / HANDLE_W, 0, 1)         # jasniejsza strona od gory-lewej
    hh[:] = np.array([34, 34, 44])[None, None, :] * (0.8 + 0.5 * hl[..., None])
    # rowki palcow
    groove = (np.abs(((along - 14) % 13) - 6.5) > 5.2) & (along > 14) & (along < HANDLE_LEN - 8)
    hh[groove] *= 0.55
    # pasek koloru A wzdluz rekojesci
    stripe = np.abs(side) < 2.4
    hh[stripe] = hh[stripe] * 0.3 + A * 0.75
    rgb[handle] = np.clip(hh[handle], 0, 255)
    # bolster: srebrny
    bs = 175 + 55 * np.clip(0.5 - side / HANDLE_W, 0, 1)
    for k in range(3):
        rgb[..., k] = np.where(bol, bs, rgb[..., k])

    # ---- pierscien: metal z cieniowaniem (swiatlo z gory-lewej) + srodek tuby
    ang_light = ((xs - rc[0]) * -0.6 + (ys - rc[1]) * -0.8) / np.maximum(rd, 1)
    tube = 1 - np.abs((rd - (RING_R_OUT + RING_R_IN) / 2) / ((RING_R_OUT - RING_R_IN) / 2))
    rl = 150 + 70 * ang_light * np.clip(tube * 1.4, 0, 1) + 25 * tube
    rl = np.clip(rl, 70, 255)
    ring_rgb = np.stack([rl, rl * 1.02, rl * 1.08], axis=-1)
    rgb[ring] = np.clip(ring_rgb[ring], 0, 255)

    # ---- obrys
    a_img = Image.fromarray((alpha * 255).astype(np.uint8), "L")
    dil = a_img.filter(ImageFilter.MaxFilter(9))
    outline = (np.array(dil) > 127) & ~alpha
    full_alpha = (np.array(dil) > 127)
    rgb[outline] = (10, 10, 16)

    rgba = np.zeros((S, S, 4), dtype=np.float32)
    rgba[..., :3] = rgb
    rgba[..., 3] = full_alpha * 255
    img = Image.fromarray(np.clip(rgba, 0, 255).astype(np.uint8), "RGBA")
    # wygladzanie: mnozymy kolor przez alfe przed skalowaniem, zeby nie bylo aureoli
    pre = np.array(img).astype(np.float32)
    pre[..., :3] *= pre[..., 3:4] / 255
    small = Image.fromarray(np.clip(pre, 0, 255).astype(np.uint8), "RGBA").resize((OUT, OUT), Image.BOX)
    arr = np.array(small).astype(np.float32)
    a = arr[..., 3:4]
    arr[..., :3] = np.where(a > 0, arr[..., :3] * 255 / np.maximum(a, 1), 0)
    return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8), "RGBA")


def main():
    tex = os.path.join(ROOT, "textures", "item")
    mdl = os.path.join(ROOT, "models", "item")
    itm = os.path.join(ROOT, "items")
    for d in (tex, mdl, itm):
        os.makedirs(d, exist_ok=True)
    n = 0
    for s in range(len(SHAPES)):
        for a in range(len(PAL)):
            for b in range(len(PAL)):
                name = f"k{s}_{a}_{b}"
                build(s, a, b).save(os.path.join(tex, name + ".png"), optimize=True)
                with open(os.path.join(mdl, name + ".json"), "w") as f:
                    json.dump({"parent": "minecraft:item/handheld",
                               "textures": {"layer0": f"karambitmod:item/{name}"}}, f)
                with open(os.path.join(itm, name + ".json"), "w") as f:
                    json.dump({"model": {"type": "minecraft:model", "model": f"karambitmod:item/{name}"}}, f)
                n += 1
    print("wygenerowano", n, "karambitow")
    if "--preview" in sys.argv:
        pairs = [(0, 5), (1, 2), (6, 7), (4, 6)]
        sheet = Image.new("RGBA", (3 * 256, len(pairs) * 256), (70, 70, 78, 255))
        for s in range(3):
            for k, (a, b) in enumerate(pairs):
                im = build(s, a, b).resize((256, 256), Image.NEAREST)
                sheet.alpha_composite(im, (s * 256, k * 256))
        sheet.save("/home/claude/preview.png")


if __name__ == "__main__":
    main()
