package com.karambitmod;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sun.net.httpserver.HttpServer;
import net.minecraft.util.Util;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Prosty klient Spotify Web API (Authorization Code + PKCE, bez client secret).
 * Użytkownik tworzy własną aplikację na developer.spotify.com i wpisuje Client ID w menu moda.
 * Redirect URI w aplikacji: http://127.0.0.1:8888/callback
 */
public final class Spotify {
    public record Track(String title, String artist, long progressMs, long durationMs, boolean playing, long fetchedAt) {
        public long currentProgress() {
            if (!playing) return progressMs;
            return Math.min(durationMs, progressMs + (System.currentTimeMillis() - fetchedAt));
        }
    }

    public static volatile Track track = null;
    public static volatile String status = "Nie połączono";

    private static final String REDIRECT = "http://127.0.0.1:8888/callback";
    private static final String SCOPE = "user-read-currently-playing user-read-playback-state user-modify-playback-state";
    private static final HttpClient HTTP = HttpClient.newHttpClient();
    private static final SecureRandom RNG = new SecureRandom();

    private static volatile String access = null;
    private static volatile long accessExpiresAt = 0;
    private static String verifier;
    private static HttpServer server;
    private static ScheduledExecutorService exec;

    private Spotify() {}

    public static void start() {
        exec = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "KarambitMod-Spotify");
            t.setDaemon(true);
            return t;
        });
        if (!Cfg.I.spotifyRefreshToken.isBlank()) status = "Łączenie...";
        exec.scheduleWithFixedDelay(Spotify::poll, 1, 2, TimeUnit.SECONDS);
    }

    public static boolean isLinked() { return !Cfg.I.spotifyRefreshToken.isBlank(); }

    // ------------------------------------------------------------ logowanie

    public static void connect() {
        if (!Cfg.I.modEnabled || !Cfg.I.spotifyEnabled) { status = "Wyłączone"; return; }
        String id = Cfg.I.spotifyClientId.trim();
        if (id.isEmpty()) { status = "Wpisz Client ID"; return; }
        try {
            byte[] raw = new byte[48];
            RNG.nextBytes(raw);
            verifier = Base64.getUrlEncoder().withoutPadding().encodeToString(raw);
            String challenge = Base64.getUrlEncoder().withoutPadding()
                    .encodeToString(MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII)));
            startCallbackServer(id);
            String url = "https://accounts.spotify.com/authorize?response_type=code"
                    + "&client_id=" + enc(id)
                    + "&scope=" + enc(SCOPE)
                    + "&redirect_uri=" + enc(REDIRECT)
                    + "&code_challenge_method=S256&code_challenge=" + challenge;
            status = "Zaloguj się w przeglądarce...";
            Util.getOperatingSystem().open(URI.create(url));
        } catch (Exception e) {
            status = "Błąd: " + e.getMessage();
        }
    }

    public static void disconnect() {
        Cfg.I.spotifyRefreshToken = "";
        Cfg.save();
        access = null;
        track = null;
        status = "Nie połączono";
    }

    private static synchronized void startCallbackServer(String clientId) throws Exception {
        if (server != null) server.stop(0);
        server = HttpServer.create(new InetSocketAddress(InetAddress.getLoopbackAddress(), 8888), 0);
        server.createContext("/callback", ex -> {
            String q = ex.getRequestURI().getRawQuery();
            String code = null;
            if (q != null) for (String p : q.split("&")) if (p.startsWith("code=")) code = java.net.URLDecoder.decode(p.substring(5), StandardCharsets.UTF_8);
            String body = "<html><body style='font-family:sans-serif;background:#121212;color:#1db954;text-align:center;padding-top:15vh'>"
                    + (code != null ? "<h1>Połączono z Minecraftem!</h1><p>Możesz zamknąć tę kartę.</p>" : "<h1>Nie udało się połączyć.</h1>")
                    + "</body></html>";
            byte[] b = body.getBytes(StandardCharsets.UTF_8);
            ex.getResponseHeaders().add("Content-Type", "text/html; charset=utf-8");
            ex.sendResponseHeaders(200, b.length);
            ex.getResponseBody().write(b);
            ex.close();
            if (code != null) {
                final String c = code;
                exec.execute(() -> exchange(clientId, c));
            } else status = "Odmowa dostępu";
            new Thread(() -> { try { Thread.sleep(500); } catch (InterruptedException ignored) {} server.stop(0); }).start();
        });
        server.start();
    }

    private static void exchange(String clientId, String code) {
        Map<String, String> f = new LinkedHashMap<>();
        f.put("grant_type", "authorization_code");
        f.put("code", code);
        f.put("redirect_uri", REDIRECT);
        f.put("client_id", clientId);
        f.put("code_verifier", verifier);
        acceptToken(tokenRequest(f));
    }

    private static boolean refresh() {
        Map<String, String> f = new LinkedHashMap<>();
        f.put("grant_type", "refresh_token");
        f.put("refresh_token", Cfg.I.spotifyRefreshToken);
        f.put("client_id", Cfg.I.spotifyClientId.trim());
        return acceptToken(tokenRequest(f));
    }

    private static JsonObject tokenRequest(Map<String, String> form) {
        try {
            StringBuilder sb = new StringBuilder();
            for (var e : form.entrySet()) {
                if (sb.length() > 0) sb.append('&');
                sb.append(enc(e.getKey())).append('=').append(enc(e.getValue()));
            }
            HttpRequest req = HttpRequest.newBuilder(URI.create("https://accounts.spotify.com/api/token"))
                    .header("Content-Type", "application/x-www-form-urlencoded")
                    .POST(HttpRequest.BodyPublishers.ofString(sb.toString())).build();
            HttpResponse<String> r = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() != 200) { status = "Błąd logowania (" + r.statusCode() + ")"; return null; }
            return JsonParser.parseString(r.body()).getAsJsonObject();
        } catch (Exception e) {
            status = "Błąd sieci";
            return null;
        }
    }

    private static boolean acceptToken(JsonObject o) {
        if (o == null || !o.has("access_token")) return false;
        access = o.get("access_token").getAsString();
        accessExpiresAt = System.currentTimeMillis() + (o.get("expires_in").getAsLong() - 30) * 1000L;
        if (o.has("refresh_token")) {
            Cfg.I.spotifyRefreshToken = o.get("refresh_token").getAsString();
            Cfg.save();
        }
        status = "Połączono";
        return true;
    }

    // ------------------------------------------------------------ odczyt

    private static void poll() {
        try {
            if (!Cfg.I.modEnabled || !Cfg.I.spotifyEnabled) { track = null; status = "Wyłączone"; return; }
            if (!isLinked()) return;
            if (access == null || System.currentTimeMillis() > accessExpiresAt) {
                if (!refresh()) return;
            }
            HttpRequest req = HttpRequest.newBuilder(URI.create("https://api.spotify.com/v1/me/player/currently-playing"))
                    .header("Authorization", "Bearer " + access).GET().build();
            HttpResponse<String> r = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
            switch (r.statusCode()) {
                case 200 -> parse(r.body());
                case 204 -> { track = null; status = "Nic nie gra"; }
                case 401 -> access = null;
                case 429 -> status = "Limit zapytań, czekam...";
                default -> status = "Błąd Spotify (" + r.statusCode() + ")";
            }
        } catch (Exception e) {
            status = "Błąd sieci";
        }
    }

    private static void parse(String body) {
        JsonObject root = JsonParser.parseString(body).getAsJsonObject();
        JsonElement itemEl = root.get("item");
        if (itemEl == null || itemEl.isJsonNull()) { track = null; status = "Reklama / brak danych"; return; }
        JsonObject item = itemEl.getAsJsonObject();
        String title = item.get("name").getAsString();
        String artist = "";
        if (item.has("artists")) {
            JsonArray arr = item.getAsJsonArray("artists");
            StringBuilder sb = new StringBuilder();
            for (JsonElement a : arr) {
                if (sb.length() > 0) sb.append(", ");
                sb.append(a.getAsJsonObject().get("name").getAsString());
            }
            artist = sb.toString();
        } else if (item.has("show")) {
            artist = item.getAsJsonObject("show").get("publisher").getAsString();
        }
        long progress = root.has("progress_ms") && !root.get("progress_ms").isJsonNull() ? root.get("progress_ms").getAsLong() : 0;
        long dur = item.has("duration_ms") ? item.get("duration_ms").getAsLong() : 0;
        boolean playing = root.has("is_playing") && root.get("is_playing").getAsBoolean();
        track = new Track(title, artist, progress, dur, playing, System.currentTimeMillis());
        status = "Połączono";
    }

    // ------------------------------------------------------------ sterowanie (Spotify Premium)

    public static void next() { command("POST", "next"); }
    public static void previous() { command("POST", "previous"); }
    public static void playPause() {
        Track t = track;
        command("PUT", t != null && t.playing() ? "pause" : "play");
    }

    private static void command(String method, String action) {
        if (exec == null || access == null || !Cfg.I.modEnabled || !Cfg.I.spotifyEnabled) return;
        exec.execute(() -> {
            try {
                HttpRequest req = HttpRequest.newBuilder(URI.create("https://api.spotify.com/v1/me/player/" + action))
                        .header("Authorization", "Bearer " + access)
                        .method(method, HttpRequest.BodyPublishers.noBody()).build();
                HttpResponse<String> r = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
                if (r.statusCode() == 403) status = "Sterowanie wymaga Spotify Premium";
                poll();
            } catch (Exception ignored) {}
        });
    }

    private static String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }
}
