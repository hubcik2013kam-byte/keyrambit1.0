package com.karambitmod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Konfiguracja moda, zapisywana w config/karambitmod.json */
public class Cfg {
    public enum Anchor { HELD_ITEM, TARGET_BLOCK, PLAYER }
    public enum PShape { ORBIT, HELIX, RING, STAR, HEART, CUBE, SPHERE, CLOUD, LINE }
    public enum PType { DUST, END_ROD, FLAME, SOUL_FIRE, ELECTRIC_SPARK, HAPPY_VILLAGER }

    public static final String[] PALETTE_NAMES = {
            "Czerwony", "Pomarańczowy", "Żółty", "Zielony", "Cyjan", "Niebieski", "Fioletowy", "Różowy", "Biały", "Czarny"};
    public static final String[] SHAPE_NAMES = {"Klasyczny", "Hawk (cienki)", "Gruby"};

    // --- Główny włącznik (wyłącza wszystko) ---
    public boolean modEnabled = true;

    // --- Karambit ---
    public boolean karambitEnabled = true;
    public int karambitShape = 0;
    public int karambitColorA = 0;
    public int karambitColorB = 5;

    // --- Cząsteczki ---
    public boolean particlesEnabled = true;
    public boolean onlyWithSword = true;
    public Anchor anchor = Anchor.HELD_ITEM;
    public PShape particleShape = PShape.ORBIT;
    public PType particleType = PType.DUST;
    public boolean particleGradient = true;
    public int particleColorA = 0xFF3366;
    public int particleColorB = 0x33CCFF;
    public int particleCount = 6;
    public float particleSize = 1.0f;
    public float particleRadius = 0.6f;
    public float particleSpeed = 1.0f;

    // --- Deszcz ---
    public boolean rainEnabled = true;
    public boolean rainSplash = true;
    public boolean rainGradient = true;
    public int rainColorA = 0x4FA3FF;
    public int rainColorB = 0xBFE4FF;
    public int rainDensity = 6;        // krople / tick przy pełnym deszczu
    public float rainBounce = 0.55f;   // sprężystość odbicia
    public float rainSize = 0.6f;
    public float rainRadius = 12f;

    // --- HUD Spotify ---
    public boolean hudEnabled = true;
    public boolean hudGradient = true;
    public boolean hudProgress = true;
    public int hudColorA = 0x1DB954;
    public int hudColorB = 0xFFFFFF;
    public float hudX = 2f;      // % wolnego miejsca w poziomie
    public float hudY = 2f;      // % wolnego miejsca w pionie
    public float hudScale = 1f;

    // --- Spotify ---
    public boolean spotifyEnabled = true;
    public String spotifyClientId = "";
    public String spotifyRefreshToken = "";

    // ---------------------------------------------------------------
    public static Cfg I = new Cfg();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("karambitmod.json");
    }

    public static void load() {
        try {
            Path f = file();
            if (Files.exists(f)) {
                Cfg c = GSON.fromJson(Files.readString(f), Cfg.class);
                if (c != null) I = c;
            }
        } catch (Exception e) {
            System.err.println("[KarambitMod] Nie udało się wczytać configu: " + e);
        }
        I.sanitize();
        save();
    }

    public static void save() {
        try {
            Files.writeString(file(), GSON.toJson(I));
        } catch (Exception e) {
            System.err.println("[KarambitMod] Nie udało się zapisać configu: " + e);
        }
    }

    private void sanitize() {
        karambitShape = clamp(karambitShape, 0, 2);
        karambitColorA = clamp(karambitColorA, 0, 9);
        karambitColorB = clamp(karambitColorB, 0, 9);
        particleCount = clamp(particleCount, 1, 40);
        rainDensity = clamp(rainDensity, 1, 15);
        if (anchor == null) anchor = Anchor.HELD_ITEM;
        if (particleShape == null) particleShape = PShape.ORBIT;
        if (particleType == null) particleType = PType.DUST;
        if (spotifyClientId == null) spotifyClientId = "";
        if (spotifyRefreshToken == null) spotifyRefreshToken = "";
    }

    /** Przywraca ustawienia domyślne, zostawiając dane logowania Spotify. */
    public static void resetKeepingSpotify() {
        String id = I.spotifyClientId, tok = I.spotifyRefreshToken;
        I = new Cfg();
        I.spotifyClientId = id;
        I.spotifyRefreshToken = tok;
        save();
    }

    public static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    /** Interpolacja kolorów RGB. */
    public static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = (int) (((a >> 16) & 255) + ((((b >> 16) & 255) - ((a >> 16) & 255)) * t));
        int g = (int) (((a >> 8) & 255) + ((((b >> 8) & 255) - ((a >> 8) & 255)) * t));
        int bl = (int) ((a & 255) + (((b & 255) - (a & 255)) * t));
        return (r << 16) | (g << 8) | bl;
    }

    public String karambitModelId() {
        return "k" + karambitShape + "_" + karambitColorA + "_" + karambitColorB;
    }
}
